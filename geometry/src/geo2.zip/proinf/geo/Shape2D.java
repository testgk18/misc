package proinf.geo;

abstract class Shape2D implements IShape {

	public abstract double calculateArea();
	public abstract double getPerimeter();
}