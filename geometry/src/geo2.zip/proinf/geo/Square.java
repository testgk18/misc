package proinf.geo;

public class Square extends Rectangle {

	public Square(int x, int y, int width) {
		super(x, y, width, width);
	}

}
